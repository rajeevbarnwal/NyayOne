// NyayOne v3.2.1.08 · final-file checks (Playwright). Reviewer tooling, not a gate.
// usage: npm i playwright axe-core && node evidence/run-checks.mjs
import {chromium} from 'playwright';import fs from 'fs';
const LIB='file://'+process.cwd()+'/NYAYONE_S01_S35_v3.2.1.08.html';const AXE=fs.readFileSync('node_modules/axe-core/axe.min.js','utf8');
const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1440,height:1100},deviceScaleFactor:1,reducedMotion:'reduce'})).newPage();
await p.goto(LIB+'#/S-18?cap=1');await p.waitForTimeout(3000);
const out=await p.evaluate(async(AXE)=>{const L=window.__lib,f=L.frames.cont.el,W=f.contentWindow,D=f.contentDocument;const s=D.createElement('script');s.textContent=AXE;D.head.appendChild(s);
 const rows=[],axe=[];for(const [dv,dw] of [['m320',320],['m360',360],['m390',390],['z720',720],['d1440',1440]]){W.__ny.setDevice(dv);
 for(const sc of L.screens.filter(x=>x[2]==='cont'))for(const x of sc[4]){W.__ny.go(sc[3],undefined,x[0]);const vp=D.querySelector('.vp');let min=999;
  vp.querySelectorAll('button:not([disabled]),a[href],input:not([disabled]),select,textarea,summary,[role=button],[role=switch],[role=radio],[role=tab],[role=checkbox]').forEach(e=>{let r=e.getBoundingClientRect();if(!r.width&&!r.height)return;if((e.type==='checkbox'||e.type==='radio')&&e.closest('label'))r=e.closest('label').getBoundingClientRect();min=Math.min(min,r.width,r.height);});min=Math.round(min*10)/10;
  rows.push([sc[0],x[0],dv,vp.scrollWidth-dw,vp.querySelectorAll('h1').length,vp.querySelectorAll('main,[role=main]').length,Math.round(min*10)/10]);
  if(true){const a=await W.axe.run(vp);axe.push({id:sc[0],st:x[0],dv,violations:a.violations.map(v=>[v.id,v.impact,v.nodes.length]),incomplete:a.incomplete.map(v=>[v.id,v.nodes.length])});}}}
 return {rows,axe};},AXE);
fs.writeFileSync('evidence/final-checks.json',JSON.stringify(out,null,1));await b.close();console.log(out.rows.length,'layout rows,',out.axe.length,'axe runs');
