// NyayOne v3.2.1.08 · fresh screenshots of the FINAL file (Playwright, DPR 1, reduced motion). Reviewer tooling; not a gate.
// usage: npm i playwright && node evidence/run-captures.mjs   -> evidence/captures/<id>-<state>-<dev>.png + captures.json (with the final HTML sha256)
import {chromium} from 'playwright';import fs from 'fs';import crypto from 'crypto';
const FILE='NYAYONE_S01_S35_v3.2.1.08.html',LIB='file://'+process.cwd()+'/'+FILE,H=crypto.createHash('sha256').update(fs.readFileSync(FILE)).digest('hex');
/* v3.2.1.08 changed states: the nine S-03 focus-bearing rows (captured with real page focus; focus ring intact). */
const SHOTS=['persona-expanded','language-expanded','keyboard-focus'].flatMap(st=>['m390','m360','d1440'].map(dv=>['S-03',st,dv]));
const DEV0={m360:[360,800]};
const DEV=Object.assign({m320:[320,568],m390:[390,844],d1440:[1440,1024]},DEV0);fs.mkdirSync('evidence/captures',{recursive:true});
const b=await chromium.launch();const out=[];
for(const [id,st,dv,extra] of SHOTS){const [w,h]=DEV[dv];const p=await (await b.newContext({viewport:{width:w,height:h},deviceScaleFactor:1,reducedMotion:'reduce'})).newPage();
 let url=LIB+'#/'+id+'?state='+st+'&dev='+dv+'&cap=1'+(extra||'');
 if(/^review-(edit|delete|deleted)/.test(st)){await p.goto(LIB+'#/S-35?state=review&session=se-2207&dev='+dv+'&cap=1');await p.waitForTimeout(2500);
  const f=p.frameLocator('iframe:visible');await f.locator('[data-star="5"]').click();await f.locator('#rvt').fill('Clear and useful guidance.');await f.locator('[data-rvcreate5]').click();await p.waitForTimeout(400);
  if(st==='review-deleted'){await p.evaluate(()=>{location.hash='#/S-35?state=review-delete-confirm&session=se-2207&dev=m390&cap=1';});await p.waitForTimeout(1500);await f.locator('[data-rvdel6]').click();}
  else await p.evaluate(u=>{location.hash=u;},url.split('#')[1]?('#'+url.split('#')[1]+'&session=se-2207'):'');}
 else await p.goto(url);
 await p.waitForTimeout(1800);const f='evidence/captures/'+[id,st,dv].join('-')+'.png';await p.screenshot({path:f});out.push({file:f,id,state:st,dev:dv,finalHtmlSha256:H});await p.context().close();}
fs.writeFileSync('evidence/captures/captures.json',JSON.stringify(out,null,1));await b.close();console.log(out.length,'captures of',H);

// v3.2.1.08 changed states (also capture): #/S-35?state=review-delete-failed&session=se-2209&dev=m390 after creating a text review (moderation pending), and the same with session=se-2207 after a rating-only review (published). See VERIFICATION.md.
