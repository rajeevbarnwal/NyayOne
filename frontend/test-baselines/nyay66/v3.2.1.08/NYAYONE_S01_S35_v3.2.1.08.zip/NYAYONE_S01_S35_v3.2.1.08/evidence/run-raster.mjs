// NyayOne v3.2.1.08 · D5 raster comparison (Playwright, DPR 1). Reviewer tooling; not a gate.
// Self-contained: runs from a fresh extraction of NYAYONE_S01_S35_v3.2.1.08.zip. No earlier workspace files needed.
// usage (package root): npm i playwright pixelmatch pngjs && npx playwright install chromium && node evidence/run-raster.mjs
// Step 1 extracts the frozen R2 and Revision L bytes from the shipped canonical input source/inputs/NYAYONE_S01_S35_v3.2.1.05.html,
// verifies their SHA-256, and writes them to evidence/_extracted/. Source bytes are never modified.
// Step 2 compares 78 Revision L + 42 R2 state/viewports: library scene vs the extracted standalone source, using only the
// reviewer-frame normalization documented by the independent v06 review (bezel/scaler/radius/offset removed identically).
// v3.2.1.08: the standalone oracle keeps its correct order (bare BEFORE the focus-bearing state, focus ring left intact; nothing
// masked, hidden, recoloured or cropped). Every row also records the focus state of BOTH sides (active element, data-kbfocus,
// :focus-visible, aria-expanded) so S-03 is judged on state preservation, not on screenshot equality alone.
import {chromium} from 'playwright';import fs from 'fs';import crypto from 'crypto';import {PNG} from 'pngjs';import pixelmatch from 'pixelmatch';
const ROOT=process.cwd(),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const V05='source/inputs/NYAYONE_S01_S35_v3.2.1.05.html',V05H='1999a2a43da52664fcaf805f4cf79ddea86b89c319df482e38140862bef8c767';
const WANT={r2:'3bfdbaac7536d8ceeae660c57286b58f1b03cdc6a53545c458b3bc7636198a07',revl:'338d5fd22b5e9e8c3c7599846428c99b151b3adf21907f69998a54fdefe33252'};
const v05=fs.readFileSync(V05,'utf8');if(sha(v05)!==V05H)throw new Error('canonical input hash mismatch: '+V05);
const blk=id=>{const a='<script type="text/plain" id="'+id+'">',i=v05.indexOf(a);if(i<0)throw new Error('missing block '+id);const j=v05.indexOf('</script>',i+a.length);return v05.slice(i+a.length,j).split('<\uE000').join('<');};
fs.mkdirSync('evidence/_extracted',{recursive:true});const SRC={};
for(const k of ['r2','revl']){const t=blk('src-'+k);const h=sha(t);if(h!==WANT[k])throw new Error(k+' extracted hash '+h+' != '+WANT[k]);const p='evidence/_extracted/'+k+'.html';fs.writeFileSync(p,t);SRC[k]='file://'+ROOT+'/'+p;console.log('extracted',k,h);}
const LIB='file://'+ROOT+'/NYAYONE_S01_S35_v3.2.1.08.html',LIBH=sha(fs.readFileSync('NYAYONE_S01_S35_v3.2.1.08.html'));
const NORM='.bezel{width:auto!important;padding:0!important;border-radius:0!important;background:none!important;filter:none!important;box-shadow:none!important}.bezel>div{width:auto!important;height:auto!important;overflow:visible!important}.scaler{transform:none!important}.vp{border-radius:0!important}body>*:not(.stagewrap):not(#stage):not(main){display:none!important}';
function normalize(css){const st=document.createElement('style');st.textContent=css;document.head.appendChild(st);let n=document.querySelector('.vp'),vp=n;while(n&&n!==document.body){const par=n.parentElement;if(!par)break;[...par.children].forEach(c=>{if(c!==n&&c.tagName!=='SCRIPT'&&c.tagName!=='STYLE')c.style.setProperty('display','none','important')});if(n!==vp){for(const k of ['padding','margin'])n.style.setProperty(k,'0','important');n.style.setProperty('display','block','important');n.style.setProperty('width','auto','important');n.style.setProperty('max-width','none','important');n.style.setProperty('border','0','important')}n=par}document.body.style.margin='0';document.body.style.padding='0';}
const geom=()=>{const vp=document.querySelector('.vp'),r=vp.getBoundingClientRect();return [...vp.querySelectorAll('*')].map(e=>{const z=e.getBoundingClientRect();return [e.tagName,e.className?.baseVal||e.className,[z.x-r.x,z.y-r.y,z.width,z.height].map(n=>Math.round(n*1000)/1000)]})};
const fst=()=>{const a=document.activeElement;const ids=sel=>[...document.querySelectorAll(sel)].map(e=>e.id||e.tagName);return {active:a?(a.id||a.tagName):null,kbfocus:ids('[data-kbfocus]'),visibleFocus:ids(':focus-visible'),expanded:ids('[aria-expanded="true"]')}};
const b=await chromium.launch({headless:true});const opt={viewport:{width:1920,height:1600},deviceScaleFactor:1,reducedMotion:'reduce',locale:'en-IN',timezoneId:'Asia/Kolkata'};
const p=await b.newPage(opt),q=await b.newPage(opt);for(const x of [p,q])await x.route(/^https?:/,r=>r.abort());
await p.goto(LIB);const screens=await p.evaluate(()=>__lib.screens.filter(s=>s[2]==='r2'||s[2]==='revl'));const out=[];
for(const s of screens)for(const [state] of s[4])for(const dev of ['m390','m360','d1440']){
 await p.goto('about:blank');await p.goto(LIB+'#/'+s[0]+'?'+new URLSearchParams({state,dev,cap:'1'}));await p.waitForFunction(()=>__lib.scene().doc?.querySelector('.vp'));await p.waitForTimeout(250);
 const f=p.frames().find(x=>x!==p.mainFrame());await f.evaluate(async()=>document.fonts.ready);
 await q.goto(SRC[s[2]]);await q.waitForSelector('.vp');
 await q.evaluate(({s,state,dev,NORM,norm})=>{
  if(s[2]==='r2'){S.screen=s[3];S.st[s[3]]=state;S.dev=dev;build();}
  else{const n=window.__ny;n.bare(true);n.setDevice(dev);let k=s[3];if(s[0]==='S-07'&&state==='popup')k='s14p';if(s[0]==='S-10'&&state==='academic')k='s10b';n.go(k);
   if(s[0]==='S-05'){const o=document.querySelector('[data-rig-otp="'+state+'"]');o&&o.click();}
   if(s[0]==='S-03'){if(state==='persona-expanded')document.querySelector('.vp [data-lbx-btn=persona]').click();else if(state==='language-expanded')document.querySelector('.vp [data-lbx-btn=language]').click();else if(state==='keyboard-focus'){const e=document.querySelector('.vp #lbxbtn-persona');e.setAttribute('data-kbfocus','1');e.focus();}}}
  if(s[2]==='r2')(new Function('css',norm))(NORM);},{s,state,dev,NORM,norm:'('+normalize.toString()+')(css)'});
 await q.evaluate(async()=>document.fonts.ready);
 const a=PNG.sync.read(await q.locator('.vp').screenshot({animations:'disabled'})),c=PNG.sync.read(await f.locator('.vp').screenshot({animations:'disabled'}));
 const row={screen:s[0],source:s[2],state,dev,dimensions:[a.width,a.height,c.width,c.height]};
 if(a.width!==c.width||a.height!==c.height){row.dimensionMismatch=true;out.push(row);continue;}
 let raw=0,sum=0;for(let i=0;i<a.data.length;i+=4){let d=0;for(let j=0;j<3;j++){const v=Math.abs(a.data[i+j]-c.data[i+j]);d+=v;sum+=v}if(d)raw++}
 Object.assign(row,{rawPixels:raw,rgbMean:sum/a.width/a.height/3,perceptualPixels:pixelmatch(a.data,c.data,null,a.width,a.height,{threshold:.1,includeAA:false}),geometryIdentical:JSON.stringify(await q.evaluate(geom))===JSON.stringify(await f.evaluate(geom)),textIdentical:await q.locator('.vp').innerText()===await f.locator('.vp').innerText()});
 row.focusStandalone=await q.evaluate(fst);row.focusLibrary=await f.evaluate(fst);row.focusStateIdentical=JSON.stringify(row.focusStandalone)===JSON.stringify(row.focusLibrary);
 out.push(row);console.log(s[0],state,dev,raw);}
await b.close();
const sum={libraryHtmlSha256:LIBH,rows:out.length,revl:out.filter(r=>r.source==='revl').length,r2:out.filter(r=>r.source==='r2').length,rawZero:out.filter(r=>r.rawPixels===0).length,perceptualZero:out.filter(r=>r.perceptualPixels===0).length,dimensionMismatch:out.filter(r=>r.dimensionMismatch).length,focusStateIdentical:out.filter(r=>r.focusStateIdentical).length,s03Rows:out.filter(r=>r.screen==='S-03').map(r=>({state:r.state,dev:r.dev,rawPixels:r.rawPixels,perceptualPixels:r.perceptualPixels,focusStateIdentical:r.focusStateIdentical,library:r.focusLibrary}))};
fs.writeFileSync('evidence/raster-results.json',JSON.stringify({summary:sum,rows:out},null,1));console.log(JSON.stringify(sum));
