# Source and state map · v3.2.1.08
| ID | Source | Scene key(s) | States |
|---|---|---|---|
| S-01 | R2 | s01 | 3 |
| S-02 | R2 | s02 | 2 |
| S-03 | Revision L | s03 (+ rig hooks) | 4 |
| S-04 | Revision L | s04 | 1 |
| S-05 | Revision L | s05 (+ rig OTP) | 8 |
| S-06 | R2 | s06 | 9 |
| S-07 | Revision L | s14 (dashboard alias), s14p (popup) | 2 |
| S-08, S-09 | Revision L | s08, s09 | 1 each |
| S-10 | Revision L | s10a, s10b | 2 |
| S-11 to S-13 | Revision L | s11 to s13 | 1 each |
| **S-14** | Revision L | **s14 dashboard** (corrected from s14p) | 1 |
| S-15 to S-17 | Revision L | s15 to s17 | 1 each |
| S-18 to S-21, S-25 to S-35 | continuation | s18 … s35 | 191 total, incl. review-delete-confirm, review-deleted, review-delete-failed (see source/continuation-states.json) |
| S-22 to S-24 | none | reserved | 0 |

Totals: R2 14 · Revision L 26 · continuation 191 = 231.
Bridges (viewer-level, source bytes unchanged): R2 s02-continue/s02-skip → S-03; R2 s06-back/s06-done → S-04; Revision L Privacy Centre → S-19; continuation s17x → S-17, s03x → S-03, s15x → S-15.

S-35 review states without a session use the sample session se-2207 (written to the address). Viewer context kept on state/device change: S-21 id/from · S-28 id · S-29 ids · S-32 tutor · S-33 slot/tutor · S-34 session · S-35 session.
