# Changelog · v3.2.1.08 (viewer repair only)

- **S-03 focus preserved through viewer initialization** (`source/library-adapter.js`, Revision L branch of `apply()`): reviewer normalization (`__ny.bare(true)`) now runs before the focus-bearing S-03 state is applied, and the two menu states confirm focus on their listbox after the last rebuild. S-03 only; no other screen's order changes.
- Version metadata v3.2.1.07 → v3.2.1.08 (library shell, adapter, continuation label via build core).
- `evidence/run-raster.mjs`: retargeted to v08; the standalone oracle keeps its correct order; each row now records focus state for both sides. Nothing masked, hidden, recoloured or cropped.
- `evidence/run-captures.mjs`: now captures the nine changed S-03 states.
- Byte sizes reported with a byte-aware method. v07's HTML is 3,062,726 UTF-8 bytes (3,062,243 was its UTF-16 length); its SHA-256 was correct.

Unchanged: R2 and Revision L bytes, continuation CSS/behaviour, v07 review copy, static-aggregate disclosure, booking context, clock, S-14 mapping, routing, S-22 to S-24 reservations, all deferrals.
