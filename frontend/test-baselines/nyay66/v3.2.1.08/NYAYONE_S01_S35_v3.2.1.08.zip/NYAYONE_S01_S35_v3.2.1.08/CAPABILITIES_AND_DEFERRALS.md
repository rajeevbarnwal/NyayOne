# Capabilities and deferrals · v3.2.1.08
Reserved, not designed: S-22, S-23, S-24.
Not built, and disclosed in the UI: internship Apply (no endpoint); student refund-status read (none, so no polling); student admin-exception request after no_auto_refund; export download endpoint (status only); live payment, video, camera or backend; dark mode (parked).
Review policy source: current-source/backend/app/services/tutoring/reviews.py (create/edit, EDIT_WINDOW_DAYS=7, 1 to 5, 10 to 1,000, re-moderation on changed text). Delete review: restored in v06 as a PROTOTYPE flow (confirm, success, simulated failure) following reviews.py delete (owned soft delete, any time, removed from public rating; a deleted review still blocks a new one). Nothing is sent; production SessionScreens.tsx is create-only. Owner decision pending.
Optional mobile fold refinement: NOT APPLIED in v06 either. The proposal (for approval): S-20/S-27/S-31 put Saved/My sessions and Filters in one wrapping two-column utility row, target the first result about 48 to 64 px earlier, keep 48 px hitboxes and an explicit filter count. S-32 collapses timezone/day under a selected-time summary that expands on related errors. S-29 gets shorter explanatory copy. S-28 gets less secondary spacing. There are no measured before/after positions yet, because no layout was changed.
Open decisions: 1) approve the library as the review surface; 2) the about:srcdoc adaptation; 3) the R2 raster result once run-raster.mjs runs; 4) the Delete review button; 5) the fold refinement.


## Mentor rating aggregate (v3.2.1.08)
- **Backend contract:** an owned soft delete removes the review from the public aggregate (reviews.py delete/recompute).
- **This prototype:** the rating shown on S-31/S-32 (for example "4.8 from 31 ratings") is a **static aggregate projection**. The simulated create/delete changes only the session review record. Measured on v3.2.1.08: 4.8 / 31 before and after a published rating was created and deleted.
- This is **not** proof of a live aggregate refresh, and no aggregate algorithm or backend change is proposed.
