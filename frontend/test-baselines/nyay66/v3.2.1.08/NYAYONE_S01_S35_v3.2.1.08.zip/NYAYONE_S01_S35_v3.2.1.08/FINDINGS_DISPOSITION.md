# Findings disposition · v3.2.1.08

| Finding | Disposition |
|---|---|
| S-03 persona/language/keyboard focus lost on library entry (9 raster rows) | **Fixed in the viewer.** Normalize before state; confirm menu focus after the last rebuild. 9/9 cold, warm, device, Back/Forward and standalone-parity checks pass in this environment. Pixel rows: NOT RUN here. |
| Desktop menu residual (27 / 457 raw px under runtime-only restoration) | Investigated by DOM: popup rect, active option and all element rects now match the oracle at 0.1 px. Pixels not measured; no antialiasing claim made. |
| v07 byte size stated as 3,062,243 | Corrected: 3,062,726 UTF-8 bytes. v08 sizes measured as bytes. |
| Historical 120/120 | Not a valid focus-preservation oracle (both sides lost focus). Historical files untouched. |
