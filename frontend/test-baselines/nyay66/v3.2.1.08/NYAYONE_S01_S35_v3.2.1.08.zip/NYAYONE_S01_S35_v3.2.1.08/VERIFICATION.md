# Verification · v3.2.1.08

Final file `NYAYONE_S01_S35_v3.2.1.08.html` · sha256 `8dcb94f89df7b434022e1c0d599e57d4348224b1ea7c5f5127e45705eb75c7f8` · **3,063,435 bytes** (measured as UTF-8 bytes with TextEncoder, not string length).

## Run on the final file (Claude Design preview, Chromium)
| Check | Result |
|---|---|
| Rebuild from shipped inputs | byte-exact (build core run in-tool; `node source/build.mjs` prints BYTE-EXACT) |
| R2 / Revision L embedded bytes | 3bfdbaac…198a07 / 338d5fd2…f33252, unchanged |
| Continuation | identical to v07 except the version label (12 label lines; label reverted = v07 continuation byte-for-byte) |
| v07 rebuild from its own inputs | byte-exact (82275d55…33be2f75, 3,062,726 bytes) |
| S-03 cold deep link, 3 states × 390/360/1440 | **9/9** correct active element, expanded state and keyboard marker |
| Warm state change, device change, Back/Forward | pass (see evidence/focus-regression-v08.json) |
| Other sources after S-03 | no focus theft; address/title match the visible screen |
| S-03 parity with standalone frozen oracle | **9/9** identical relative geometry (0.1 px), text, active element, marker, expanded state |
| Console errors | 0 |

## NOT RUN here
- **120-row raster comparison** (evidence/run-raster.mjs): Playwright not available. No pixel counts are claimed; the 111/120 → ? outcome must be measured. The helper now also records focus state for both sides on every row.
- **Visible focus ring**: `:focus-visible` cannot match in this preview (no OS focus on the window). Asserted via active element and `data-kbfocus` instead.
- **Fresh screenshots**: the scene iframe cannot be captured by this tool. evidence/run-captures.mjs captures the nine changed S-03 states with real page focus.
- Continuation smoke/layout/axe re-run: not repeated; the continuation bytes are unchanged apart from the version label, and the v07 results stand for those bytes only by that equivalence (not a new run).
- Real browser zoom, native screen reader, physical devices, live backend/payment/video: not tested.
