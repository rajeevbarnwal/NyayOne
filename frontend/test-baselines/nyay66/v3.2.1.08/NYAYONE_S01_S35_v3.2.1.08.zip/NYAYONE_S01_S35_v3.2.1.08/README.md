# NyayOne S-01 to S-35 · consolidated design library · v3.2.1.08

**Status:** PROPOSED, PENDING OWNER APPROVAL. Viewer repair only; no design change.
**Deliverable:** `NYAYONE_S01_S35_v3.2.1.08.html` · sha256 `8dcb94f89df7b434022e1c0d599e57d4348224b1ea7c5f5127e45705eb75c7f8` · 3,063,435 bytes. One self-contained offline file; publish it as the single artifact.
**Built from:** v07 sources (v07 rebuilt byte-exact first) with the hash-verified v05 input `1999a2a4…bef8c767`. `node source/build.mjs` prints BYTE-EXACT or MISMATCH.

## Embedded sources
- S-01, S-02, S-06: approved R2, byte-identical (3bfdbaac…198a07).
- S-03 to S-05, S-07 to S-17: frozen Revision L, byte-identical (338d5fd2…f33252).
- S-18 to S-21, S-25 to S-35: continuation v3.2.1.08 (cd26225f…76c72a), identical to v07 apart from its version label.
32 designed IDs; S-22 to S-24 reserved. 231 reviewer state entries.

## The one change
S-03 persona-expanded, language-expanded and keyboard-focus now keep their focus when opened in the library, cold or warm, at 390/360/1440. See CHANGELOG and VERIFICATION (includes NOT RUN items).

## Files
README · CHANGELOG · FINDINGS_DISPOSITION · SOURCE_STATE_MAP · CAPABILITIES_AND_DEFERRALS · VERIFICATION · comparison/COMPARISON.html · preview.svg/png (static composition, labelled) · evidence/ (focus-regression-v08.json, run-raster.mjs, run-captures.mjs, run-checks.mjs) · source/ · MANIFEST_v3.2.1.08.json · SHA256SUMS.txt.
