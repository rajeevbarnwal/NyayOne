(function(){
var VERSION='v3.2.1.08';
var SRC={
 r2:{el:'src-r2',label:'Approved R2 standalone',hash:'3bfdbaac…198a07',dev:['m390','m360','d1440']},
 revl:{el:'src-revl',label:'Frozen Revision L',hash:'338d5fd2…f33252',dev:['m390','m360','d1440']},
 cont:{el:'src-cont',label:'S-18 to S-35 continuation v3.2.1.08',hash:'__CONTHASH__',dev:['m320','m360','m390','z720','d1440']}};
var DEVNAME={m320:'320',m360:'360',m390:'390',z720:'720',d1440:'1440'};
var R2ST={s01:[['checking','Checking session'],['error','Connection failure · retry'],['resolved','Session resolved · routing']],
 s02:[['default','Introduction'],['focus','Continue focused']],
 s06:[['entry','Entry · registered mobile'],['invalidnum','Entry · validation error'],['submitting','Submitting'],['challenge','Recovery code sent'],['wrong','Incorrect code · attempts left'],['expired','Code expired'],['locked','Locked after repeated attempts'],['neterr','Network failure · retry'],['success','Recovery confirmed']]};
var OTP=[['default','default'],['focus','focus'],['sending','sending'],['verifying','verifying'],['wrong','wrong'],['expired','expired'],['rate','rate'],['resent','resent']];
var S03X=[['default','Default'],['persona-expanded','Persona menu expanded'],['language-expanded','Language menu expanded'],['keyboard-focus','Keyboard focus on persona']];
function one(k){return [['default',k]];}
/* [id, name, source, scene key, states]. S-14 is the frozen s14 dashboard (authorities/nyay66-conformance.mjs); S-07 keeps its dashboard alias and the s14p popup. */
var SCR=[
 ['S-01','Session boot check','r2','s01',R2ST.s01],
 ['S-02','Onboarding introduction','r2','s02',R2ST.s02],
 ['S-03','Gateway','revl','s03',S03X],
 ['S-04','Choose identity','revl','s04',one('Default')],
 ['S-05','Enter OTP','revl','s05',OTP],
 ['S-06','Account recovery','r2','s06',R2ST.s06],
 ['S-07','Home dashboard and post-login popup','revl','s14',[['default','Dashboard (alias of S-14)'],['popup','Centered post-login popup']]],
 ['S-08','Create account','revl','s08',one('Default')],
 ['S-09','Verify new account','revl','s09',one('Default')],
 ['S-10','Profile: personal and academic','revl','s10a',[['personal','Personal'],['academic','Academic (errors)']]],
 ['S-11','Interests','revl','s11',one('Default')],
 ['S-12','Completed','revl','s12',one('Default')],
 ['S-13','Resume profile','revl','s13',one('Default')],
 ['S-14','Home dashboard','revl','s14',one('Dashboard')],
 ['S-15','Email verification','revl','s15',one('Default')],
 ['S-16','Guardian consent','revl','s16',one('Default')],
 ['S-17','Profile view','revl','s17',one('Default')],
 ['S-18','Notifications and appearance','cont','s18',null],
 ['S-19','Privacy preferences and requests','cont','s19',null],
 ['S-20','Browse internships','cont','s20',null],
 ['S-21','Internship detail','cont','s21',null],
 ['S-22','Reserved: pending backend contract',null],
 ['S-23','Reserved: pending backend contract',null],
 ['S-24','Reserved: pending backend contract',null],
 ['S-25','Saved internships','cont','s25',null],
 ['S-26','Internship empty and recovery view','cont','s26',null],
 ['S-27','Law school search','cont','s27',null],
 ['S-28','Law school detail','cont','s28',null],
 ['S-29','Law school comparison','cont','s29',null],
 ['S-30','Saved and followed schools','cont','s30',null],
 ['S-31','Mentor and tutor discovery','cont','s31',null],
 ['S-32','Mentor detail and slots','cont','s32',null],
 ['S-33','Booking hold and payment','cont','s33',null],
 ['S-34','Confirmed session detail','cont','s34',null],
 ['S-35','My sessions and session lifecycle','cont','s35',null]];
var CONTST=/*CONTSTATES*/null;
SCR.forEach(function(s){if(s[2]==='cont'&&CONTST&&CONTST[s[0]])s[4]=CONTST[s[0]];});
/* Viewer bridges: destinations that the approved sources announce as "outside" but that this library now embeds.
   Deliberately NOT bridged: Revision L dashboard tiles and app-nav items (Internships, Moot Court, Research, Mentors, Community)
   stay "Preview only / full product" as approved; activating them would change approved S-07/S-14 behaviour. */
var BRIDGE={
 r2:[['[data-route="s02-continue"]','S-03','after'],['[data-route="s02-skip"]','S-03','after'],['[data-route="s06-back"]','S-04','after'],['[data-route="s06-done"]','S-04','after']],
 revl:[['button[data-ann="The Privacy Centre is outside this prototype"]','S-19','instead']],
 cont:{s17x:'S-17',s03x:'S-03',s15x:'S-15'}};
window.__BRIDGES=BRIDGE;
function byId(id){for(var i=0;i<SCR.length;i++)if(SCR[i][0]===id)return SCR[i];return null;}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
var frames={},cur={src:null},bar=document.getElementById('bar'),ix=document.getElementById('index'),strip=document.getElementById('strip'),panel=document.getElementById('panel');
function srcText(k){var t=document.getElementById(SRC[k].el).textContent;t=t.split('<\uE000').join('<');if(k==='cont')t=t.replace(/<head>/i,'<head><base href="about:srcdoc">');return t;}
function frameFor(k){if(frames[k])return frames[k];var f=document.createElement('iframe');f.className='scene';f.title='Screen';f.hidden=true;f.setAttribute('data-src',k);document.body.insertBefore(f,document.getElementById('sources'));
 frames[k]={el:f,ready:false};f.addEventListener('load',function(){frames[k].ready=true;hook(k);setTimeout(apply,60);});f.srcdoc=srcText(k);return frames[k];}
function W(k){return frames[k]&&frames[k].el.contentWindow;}function D(k){return frames[k]&&frames[k].el.contentDocument;}
/* ---------- index ---------- */
(function(){var designed=SCR.filter(function(s){return s[2];}).length,res=SCR.length-designed,tot=0;SCR.forEach(function(s){if(s[4])tot+=s[4].length;});
 document.getElementById('meta').innerHTML='<span class="pill">'+designed+' designed IDs</span><span class="pill warn">'+res+' reserved</span><span class="pill">'+tot+' reachable states</span><span class="pill">'+VERSION+' · proposed</span><span class="pill">Light mode only</span>';
 var groups=[['Launch, sign-in and recovery',['S-01','S-02','S-03','S-04','S-05','S-06']],['Account, onboarding and profile',['S-07','S-08','S-09','S-10','S-11','S-12','S-13','S-14','S-15','S-16','S-17']],['Settings and privacy',['S-18','S-19']],['Internships',['S-20','S-21','S-22','S-23','S-24','S-25','S-26']],['Law schools',['S-27','S-28','S-29','S-30']],['Mentors and sessions',['S-31','S-32','S-33','S-34','S-35']]];
 var h='',opts='';groups.forEach(function(g){h+='<h2 class="grp">'+esc(g[0])+'</h2><ul class="ix-list">';opts+='<optgroup label="'+esc(g[0])+'">';g[1].forEach(function(id){var s=byId(id);
  if(!s[2]){h+='<li class="ix-item res"><span class="open" aria-disabled="true"><span class="id">'+id+'</span><span class="nm">Reserved</span></span><span class="src">'+esc(s[1])+'. Not designed, not activated.</span></li>';opts+='<option disabled>'+id+' · Reserved</option>';return;}
  opts+='<option value="'+id+'">'+id+' · '+esc(s[1])+'</option>';
  var st=s[4]||[],first=st.slice(0,6),rest=st.slice(6);
  var link=function(x){return '<a href="#/'+id+'?state='+encodeURIComponent(x[0])+'">'+esc(x[1])+'</a>';};
  h+='<li class="ix-item"><a class="open" href="#/'+id+'"><span class="id">'+id+'</span><span class="nm">'+esc(s[1])+'</span></a><span class="src">'+esc(SRC[s[2]].label)+' · '+st.length+' state'+(st.length===1?'':'s')+'</span>'
   +(st.length>1?'<div class="stl">'+first.map(link).join('')+'</div>'+(rest.length?'<details class="more"><summary>'+rest.length+' more states</summary><div class="stl">'+rest.map(link).join('')+'</div></details>':''):'')+'</li>';});h+='</ul>';opts+='</optgroup>';});
 document.getElementById('groups').innerHTML=h;document.getElementById('scrsel').innerHTML=opts;})();
/* ---------- routing ---------- */
function parse(){var h=location.hash.replace(/^#\/?/,'');if(!h||h==='index')return null;var p=h.split('?'),q={};(p[1]||'').split('&').forEach(function(kv){if(!kv)return;var a=kv.split('=');q[decodeURIComponent(a[0])]=decodeURIComponent(a[1]||'');});return {id:p[0].toUpperCase(),q:q};}
function hashOf(id,q){var o=[];for(var k in q)if(q[k]!=null&&q[k]!=='')o.push(encodeURIComponent(k)+'='+encodeURIComponent(q[k]));return '#/'+id+(o.length?'?'+o.join('&'):'');}
function autoDev(k){var w=window.innerWidth,L=SRC[k].dev;function has(d){return L.indexOf(d)>=0;}
 if(w<360)return has('m320')?'m320':'m360';if(w<390)return 'm360';if(w<720)return 'm390';if(w<1024&&has('z720'))return 'z720';return w<1024?'m390':'d1440';}
function mode(q){return q.cap==='1'?'cap':q.full==='1'?'full':'lib';}
function setMode(m){document.body.classList.toggle('cap',m==='cap');document.body.classList.toggle('full',m==='full');strip.hidden=m!=='full';bar.hidden=m!=='lib';if(m!=='lib')closePanel();}
function showIndex(){for(var k in frames)frames[k].el.hidden=true;bar.hidden=true;strip.hidden=true;document.body.classList.remove('cap','full');ix.hidden=false;document.title='NyayOne · S-01 to S-35 consolidated design library · '+VERSION+' · proposed, pending owner approval';try{ix.focus();}catch(e){}}
var pending=null,applying=0;
function describe(s,st,dev){document.getElementById('who').innerHTML='<b>'+s[0]+'</b> <span class="nm2">'+esc(s[1])+'</span>';
 document.getElementById('whosrc').textContent=SRC[s[2]].label+' ('+SRC[s[2]].hash+')';
 document.getElementById('stripwho').textContent=s[0]+' · '+s[1];
 document.getElementById('scrsel').value=s[0];
 document.getElementById('stsel2').innerHTML=(s[4]||[]).map(function(x){return '<option value="'+esc(x[0])+'"'+(x[0]===st?' selected':'')+'>'+esc(x[1])+'</option>';}).join('');
 document.getElementById('devsel2').innerHTML=SRC[s[2]].dev.map(function(d){return '<option value="'+d+'"'+(d===dev?' selected':'')+'>'+DEVNAME[d]+(d==='z720'?' (200% zoom reflow)':d==='m320'?' (reflow)':'')+'</option>';}).join('');
 document.getElementById('devnote').textContent=SRC[s[2]].dev.indexOf('m320')<0?'This source has 390, 360 and 1440 layouts only. At 320 its 360 layout scrolls sideways inside the scene; at 720 it uses 390.':'';
 document.getElementById('devnote').textContent+=' Reviewer clock: '+(parse()&&parse().q.now&&parse().q.now!=='clear'?parse().q.now+' (set by &now; &now=clear resets)':'default synthetic clock')+'.'+(s[0]==='S-35'?' Review states opened without a session use the sample session se-2207 (Adv. Meera Krishnan, attendance confirmed); an explicit session is never replaced.':'');
 var stl=(s[4]||[]).filter(function(x){return x[0]===st;})[0];
 document.title=s[0]+' · '+s[1]+(stl&&s[4].length>1?' · '+stl[1]:'')+' · NyayOne '+VERSION;}
function open(r){var s=byId(r.id);if(!s||!s[2]){location.replace('#/index');return;}
 ix.hidden=true;var md=mode(r.q);setMode(md);
 var st=r.q.state||(s[2]==='cont'?null:(s[4]&&s[4][0]?s[4][0][0]:'default'));var dev=r.q.dev&&SRC[s[2]].dev.indexOf(r.q.dev)>=0?r.q.dev:autoDev(s[2]);
 describe(s,st,dev);
 pending={s:s,st:st,dev:dev,q:r.q};var F=frameFor(s[2]);for(var k in frames)frames[k].el.hidden=(k!==s[2]);cur.src=s[2];
 if(F.ready)apply();}
var tries=0;
function ready(k){var w=W(k),d=D(k);if(!w||!d)return false;if(k==='r2')return !!d.querySelector('[data-screen]')&&!!d.getElementById('stsel');return !!(w.__ny&&w.__ny.go);}
var CAPCSS='.bezel{width:auto!important;padding:0!important;border-radius:0!important;background:none!important;filter:none!important;box-shadow:none!important}.bezel>div{width:auto!important;height:auto!important;overflow:visible!important}.scaler{transform:none!important}.vp{border-radius:0!important}body>*:not(.stagewrap):not(#stage):not(main){display:none!important}';
function r2chrome(d){if(!d.getElementById('lib-chrome-css')){var st=d.createElement('style');st.id='lib-chrome-css';st.textContent=CAPCSS;d.head.appendChild(st);}
 var vp=d.querySelector('.vp');if(!vp)return;var n=vp;while(n&&n!==d.body){var par=n.parentElement;if(!par)break;[].forEach.call(par.children,function(c){if(c!==n&&c.tagName!=='SCRIPT'&&c.tagName!=='STYLE')c.style.setProperty('display','none','important');});if(n!==vp){['padding','margin'].forEach(function(p){n.style.setProperty(p,'0','important');});n.style.setProperty('display','block','important');n.style.setProperty('width','auto','important');n.style.setProperty('max-width','none','important');n.style.setProperty('border','0','important');}n=par;}d.body.style.setProperty('margin','0','important');d.body.style.setProperty('padding','0','important');}
function apply(){if(!pending)return;var P=pending,s=P.s,k=s[2];if(!frames[k]||!frames[k].ready)return;if(!ready(k)){if(tries++<80)setTimeout(apply,150);return;}tries=0;var w=W(k),d=D(k);applying++;
 try{
 if(k==='r2'){var b=d.querySelector('[data-screen="'+s[3]+'"]');if(b)b.click();var sl=d.getElementById('stsel');if(sl){sl.value=P.st;sl.dispatchEvent(new w.Event('change',{bubbles:true}));}var dv=d.querySelector('[data-dev="'+P.dev+'"]');if(dv)dv.click();r2chrome(d);}
 else if(k==='revl'){var n=w.__ny;n.setDevice(P.dev);var key=s[3];if(s[0]==='S-07'&&P.st==='popup')key='s14p';if(s[0]==='S-10'&&P.st==='academic')key='s10b';
  if(d.getElementById('scr').value!==key||s[0]==='S-03'||s[0]==='S-05')n.go(key);
  if(s[0]==='S-05'){var o=d.querySelector('[data-rig-otp="'+P.st+'"]');if(o)o.click();}
  /* v3.2.1.08: reviewer normalization (bare rebuild) runs BEFORE the focus-bearing S-03 state, so the rebuild can no longer discard the open listbox focus or the keyboard-focus marker. */
  if(s[0]==='S-03'&&!d.body.hasAttribute('data-bare'))n.bare(true);
  if(s[0]==='S-03'){if(P.st==='persona-expanded'){var pb=d.querySelector('.vp [data-lbx-btn=persona]');if(pb)pb.click();}else if(P.st==='language-expanded'){var lb=d.querySelector('.vp [data-lbx-btn=language]');if(lb)lb.click();}else if(P.st==='keyboard-focus'){var fb=d.querySelector('.vp #lbxbtn-persona');if(fb){fb.setAttribute('data-kbfocus','1');fb.focus();}}}
  /* v3.2.1.08: confirm the focus-bearing S-03 state after the last rebuild (idempotent; S-03 only). */
  if(s[0]==='S-03'&&(P.st==='persona-expanded'||P.st==='language-expanded')){var kd=P.st==='persona-expanded'?'persona':'language',pp=d.querySelector('.vp #lbxpop-'+kd);if(pp&&d.activeElement!==pp)try{pp.focus();}catch(e){}}
  if(!d.body.hasAttribute('data-bare'))n.bare(true);}
 else{var q={};for(var x in P.q)if(['state','dev','cap','full'].indexOf(x)<0)q[x]=P.q[x];
  var qs=[];for(var y in q)qs.push(encodeURIComponent(y)+'='+encodeURIComponent(q[y]));
  var want='#/'+s[0].toLowerCase()+'?'+(P.st?'state='+encodeURIComponent(P.st)+'&':'')+'dev='+P.dev+(qs.length?'&'+qs.join('&'):'');if(w.location.hash!==want)w.location.hash=want;
  if(!d.body.hasAttribute('data-bare'))w.__ny.bare(true);}
 }catch(e){if(window.console)console.warn('scene apply',e);}
 pending=null;setTimeout(function(){applying--;},450);}
/* ---------- scene → library sync (D3): the address, title and controls always describe the visible screen ---------- */
function sceneLoc(k){var w=W(k),d=D(k);if(!w||!d)return null;
 if(k==='cont'){var h=(w.location.hash||'').replace(/^#\/?/,''),m=/^s-(\d+x?)(?:\?(.*))?$/.exec(h);if(!m)return null;
  if(/x$/.test(m[1]))return {bridge:BRIDGE.cont['s'+m[1]]||null};
  var q={};(m[2]||'').split('&').forEach(function(kv){if(!kv)return;var a=kv.split('=');q[decodeURIComponent(a[0])]=decodeURIComponent(a[1]||'');});
  return {id:'S-'+m[1],st:q.state,dev:q.dev,q:q};}
 if(k==='revl'){var sc=d.getElementById('scr');if(!sc)return null;var v=sc.value,r=parse()||{id:'',q:{}};
  if(v==='s14p')return {id:'S-07',st:'popup'};
  if(v==='s14')return {id:(r.id==='S-07'?'S-07':'S-14'),st:r.id==='S-07'?'default':'default'};
  if(v==='s10a'||v==='s10b')return {id:'S-10',st:v==='s10a'?'personal':'academic'};
  if(v==='s03'){var st3=d.querySelector('.vp [data-lbx-btn=persona][aria-expanded="true"]')?'persona-expanded':d.querySelector('.vp [data-lbx-btn=language][aria-expanded="true"]')?'language-expanded':(r.id==='S-03'&&r.q.state==='keyboard-focus')?'keyboard-focus':'default';return {id:'S-03',st:st3};}
  var id='S-'+v.replace(/\D/g,'');return {id:id,st:(r.id===id?r.q.state:null)};}
 if(k==='r2'){var on=d.querySelector('[data-screen][aria-pressed="true"],[data-screen][aria-current="true"],[data-screen].on');var sl=d.getElementById('stsel');if(!on)return null;
  return {id:'S-'+on.getAttribute('data-screen').replace(/\D/g,''),st:sl?sl.value:null};}
 return null;}
/* v3.2.1.07 F2: screen-aware context kept when the state or device changes (never carried to unrelated screens). */
var CTX06={'S-21':['id','from'],'S-28':['id'],'S-29':['ids'],'S-32':['tutor'],'S-33':['slot','tutor'],'S-34':['session'],'S-35':['session']};
function keepCtx(id,from,to){(CTX06[id]||[]).forEach(function(k){if(from[k]!=null&&from[k]!=='')to[k]=from[k];});}
function libGo(id,st,push){var r=parse()||{q:{}};var q={};['dev','full','cap','now'].forEach(function(k){if(r.q[k])q[k]=r.q[k];});var s=byId(id);if(q.dev&&s&&SRC[s[2]].dev.indexOf(q.dev)<0)delete q.dev;if(st)q.state=st;
 location.hash=hashOf(id,q);}
function sync(){if(applying||pending||!cur.src||ix.hidden===false)return;var k=cur.src,L=sceneLoc(k),r=parse();if(!L||!r)return;
 if(L.bridge){libGo(L.bridge,null,true);return;}
 var s=byId(L.id);if(!s||s[2]!==k)return;
 var q={};if(k==='cont'){for(var x in L.q)if(x!=='state'&&x!=='dev')q[x]=L.q[x];}if(k!=='cont'&&r.q.now&&r.q.now!=='clear'&&!q.now)q.now=r.q.now;/* v3.2.1.07: reviewer clock; the continuation carries its own &now through navigation, &now=clear drops it */
 ['full','cap'].forEach(function(z){if(r.q[z])q[z]=r.q[z];});
 var dev=L.dev||r.q.dev;if(dev)q.dev=dev;var st=L.st||(L.id===r.id?r.q.state:null);if(st)q.state=st;
 var nh=hashOf(L.id,q);if(location.hash===nh)return;
 if(L.id!==r.id)history.pushState(null,'',nh);else history.replaceState(null,'',nh);
 describe(s,st||(s[4]&&s[4][0]?s[4][0][0]:'default'),dev||autoDev(k));}
setInterval(sync,300);
/* ---------- bridges inside approved sources: explicit selectors, no source bytes changed ---------- */
function hook(k){var d=D(k);if(!d)return;(k==='cont'?[]:(BRIDGE[k]||[])).forEach(function(b){d.addEventListener('click',function(e){var t=e.target.closest&&e.target.closest(b[0]);if(!t)return;
 if(b[2]==='instead'){e.preventDefault();e.stopImmediatePropagation();libGo(b[1],null,true);}else setTimeout(function(){libGo(b[1],null,true);},700);},true);});
 ['click','keyup','change'].forEach(function(ev){d.addEventListener(ev,function(){setTimeout(sync,120);setTimeout(sync,900);},false);});try{W(k).addEventListener('hashchange',function(){setTimeout(sync,60);});}catch(e){}
 d.addEventListener('keydown',function(e){if(e.key==='Escape'&&document.body.classList.contains('full')&&!d.querySelector('[role="dialog"],[aria-expanded="true"]'))exitFull();});}
function route(){var r=parse();if(!r){showIndex();return;}open(r);}
window.addEventListener('hashchange',route);
function setQ(k,v){var r=parse();if(!r)return;if(v===null)delete r.q[k];else r.q[k]=v;location.hash=hashOf(r.id,r.q);}
function exitFull(){var r=parse();if(!r)return;delete r.q.full;delete r.q.cap;location.hash=hashOf(r.id,r.q);setTimeout(function(){try{document.getElementById('fullBtn').focus();}catch(e){}},80);}
/* ---------- controls ---------- */
function closePanel(){panel.hidden=true;document.body.classList.remove('panel');document.getElementById('ctlBtn').setAttribute('aria-expanded','false');}
document.getElementById('ctlBtn').addEventListener('click',function(){var o=panel.hidden;panel.hidden=!o;document.body.classList.toggle('panel',o);this.setAttribute('aria-expanded',o?'true':'false');if(o){document.body.style.setProperty('--ph',panel.offsetHeight+'px');document.getElementById('scrsel').focus();}});
document.getElementById('toIndex').addEventListener('click',function(){location.hash='#/index';});
document.getElementById('scrsel').addEventListener('change',function(e){libGo(e.target.value,null,true);});
document.getElementById('stsel2').addEventListener('change',function(e){var r=parse();if(!r)return;var s=byId(r.id),q={state:e.target.value};['dev','full','now'].forEach(function(k){if(r.q[k])q[k]=r.q[k];});if(s[2]==='cont')keepCtx(r.id,r.q,q);location.hash=hashOf(r.id,q);});
document.getElementById('devsel2').addEventListener('change',function(e){setQ('dev',e.target.value);});
document.getElementById('fullBtn').addEventListener('click',function(){setQ('full','1');});
document.getElementById('exitFull').addEventListener('click',exitFull);
document.addEventListener('keydown',function(e){if(e.key!=='Escape')return;if(!panel.hidden){closePanel();document.getElementById('ctlBtn').focus();return;}if(document.body.classList.contains('full')||document.body.classList.contains('cap'))exitFull();});
window.__lib={version:VERSION,screens:SCR,bridges:BRIDGE,scene:function(){return {src:cur.src,win:W(cur.src),doc:D(cur.src)};},frames:frames,sceneLoc:sceneLoc,sync:sync,dbg:function(){return {applying:applying,pending:!!pending,cur:cur.src,ixHidden:ix.hidden};}};
route();
})();
