/* NyayOne v3.2.1.08 deterministic build core. Pure string transforms (same code in build.mjs and the design tool).
   Inputs: v05 = canonical v3.2.1.05 final HTML text (sha256 1999a2a4...bef8c767); layer (v3.2.1.07-correction-layer.js), shell, parentJs, contStates (JSON text). */
function buildCore(I){
 function blk(html,id){var a='<script type="text/plain" id="'+id+'">',i=html.indexOf(a);if(i<0)throw new Error('missing block '+id);var j=html.indexOf('</script>',i+a.length);return html.slice(i+a.length,j);}
 function once(s,from,to){var n=s.split(from).length-1;if(n!==1)throw new Error('expected exactly one "'+from+'" found '+n);return s.replace(from,function(){return to;});}
 function unesc(t){return t.split('<\uE000').join('<');}
 function escB(t){return t.replace(/<(\/script|!--)/gi,function(m,g){return '<\uE000'+g;});}
 var r2=blk(I.v05,'src-r2'),revl=blk(I.v05,'src-revl'),c5=unesc(blk(I.v05,'src-cont'));
 var M4='/* ===================== v3.2.1.04 correction layer',i4=c5.indexOf(M4);if(i4<0)throw new Error('v04 layer marker missing');
 var before=c5.slice(0,i4).split('v3.2.1.05').join('v3.2.1.08'),rest=c5.slice(i4);
 var M5='/* ===================== v3.2.1.05 correction layer',i5=rest.indexOf(M5);if(i5<0)throw new Error('v05 layer marker missing');
 var l4=rest.slice(0,i5),l5=rest.slice(i5);
 l5=once(l5,'function s35(m,st){','function s35_05(m,st){');
 l5=once(l5,'function wire(vp){wire_04(vp);','function wire_05(vp){wire_04(vp);');
 var boot='rig();parseHash();build();',bi=l5.lastIndexOf(boot);if(bi<0)throw new Error('boot line missing');
 l5=l5.slice(0,bi)+I.layer06.replace(/\s+$/,'')+'\n'+l5.slice(bi);
 var cont=before+l4+l5;
 function block(id,t){return '<script type="text/plain" id="'+id+'">'+escB(t)+'</script>';}
 var js=I.parentJs.split('__CONTHASH__').join(I.contHashShort).split('/*CONTSTATES*/null').join(I.contStates.trim());
 var lib=once(I.shell,'<!--SOURCES-->',block('src-r2',r2)+'\n'+block('src-revl',revl)+'\n'+block('src-cont',cont));
 lib=once(lib,'<script>/*PARENTJS*/</script>','<script>\n'+js+'</script>');
 return {lib:lib,cont:cont,r2:r2,revl:revl};}
