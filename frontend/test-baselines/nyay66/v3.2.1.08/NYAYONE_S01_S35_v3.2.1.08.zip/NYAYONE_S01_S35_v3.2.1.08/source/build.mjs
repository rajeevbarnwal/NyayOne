// NyayOne v3.2.1.08 deterministic build. usage: node source/build.mjs   (from the package root)
// Input (hash-verified): source/inputs/NYAYONE_S01_S35_v3.2.1.05.html (1999a2a4...bef8c767) + the v08 files in source/.
import fs from 'fs';import crypto from 'crypto';import vm from 'vm';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');const rd=p=>fs.readFileSync(new URL(p,import.meta.url),'utf8');
const ctx={};vm.runInNewContext(rd('./build-core.js')+';this.buildCore=buildCore;',ctx);
const v05=rd('./inputs/NYAYONE_S01_S35_v3.2.1.05.html');if(sha(v05)!=='1999a2a43da52664fcaf805f4cf79ddea86b89c319df482e38140862bef8c767')throw new Error('v05 input hash mismatch');
const I={v05,layer06:rd('./v3.2.1.07-correction-layer.js'),shell:rd('./library-shell.html'),parentJs:rd('./library-adapter.js'),contStates:rd('./continuation-states.json'),contHashShort:'x'};
let o=ctx.buildCore(I);const ch=sha(o.cont);I.contHashShort=ch.slice(0,8)+'\u2026'+ch.slice(-6);o=ctx.buildCore(I);
const u=t=>t.split('<\uE000').join('<');
for(const [k,h] of [['r2','3bfdbaac7536d8ceeae660c57286b58f1b03cdc6a53545c458b3bc7636198a07'],['revl','338d5fd22b5e9e8c3c7599846428c99b151b3adf21907f69998a54fdefe33252']])if(sha(u(o[k]))!==h)throw new Error(k+' approved bytes changed');
fs.writeFileSync(new URL('../NYAYONE_S01_S35_v3.2.1.08.rebuilt.html',import.meta.url),o.lib);
const want=fs.readFileSync(new URL('../NYAYONE_S01_S35_v3.2.1.08.html',import.meta.url));
console.log('continuation',ch);console.log('library',sha(o.lib));console.log(sha(o.lib)===sha(want)?'BYTE-EXACT: matches the delivered file':'MISMATCH with delivered file');
