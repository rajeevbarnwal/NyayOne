/* ===================== v3.2.1.06 correction layer (F1 one review model, F3 prototype review deletion, F4 metadata) + v3.2.1.07 truthful delete-failure copy and static-aggregate note. PROPOSED, PENDING OWNER APPROVAL ===================== */
var V06=true;
/* F1: review states opened without a session use ONE clearly identified eligible sample session, written into the address.
   An explicitly supplied session is never replaced. */
var SAMPLE_RV06='se-2207';
/* F2 clock: the reviewer-only &now travels with scene navigation (viewer diagnostic, not a product route); &now=clear drops it. */
var _now05=now04;
now04=function(){if(A.q&&A.q.now==='clear'){delete A.q.now;NOW05=null;}return _now05();};
var _go01=go;
go=function(id,q,st){q=q||{};if(A.q&&A.q.now&&A.q.now!=='clear'&&q.now==null)q.now=A.q.now;if(q.now==='clear'){delete q.now;NOW05=null;}return _go01(id,q,st);};
function live06(r){return !!(r&&!r.deleted_ms);}
function delBtn06(){return btn('danger b48','trash','Delete review','data-st="review-delete-confirm"');}
var _reviewForm05=reviewForm05;
reviewForm05=function(m,se,mode,msg){
 /* F4: an unchanged Save is local feedback, not a backend rejection (reviews.py accepts unchanged values). */
 if(msg&&msg.code==='validation_error'&&msg.title==='Nothing to save.')msg={code:'no_change',warn:1,title:'No changes to save.',body:'Change the rating or the text first. Nothing was sent.'};
 var h=_reviewForm05(m,se,mode,msg);
 if(mode!=='create'){var back=btn('','back','Back to session','data-st="detail"','#2E3A8C');h=h.replace(back,back+delBtn06());}
 return h;};
function s35(m,st){
 if(/^review/.test(st)&&!A.q.session){A.q.session=SAMPLE_RV06;writeHash();}
 var se=byId(FX.sessions,A.q.session),r=se&&se.review05;
 if(se&&/^review/.test(st)&&se.status==='completed'&&reviewOK(se)){
  var chips='<div class="chips">'+stLabel(se)+attChip(se)+'</div>',back=btn('b48','back','Back to session','data-st="detail"','#2E3A8C');
  if(st==='review-delete-confirm'){
   if(!live06(r))return s35Shell(m,se,chips+statusNote('ind','info','There is no review to delete for this session.','Code: review_not_found.',back));
   return s35Shell(m,se,chips+'<section class="card stack" aria-labelledby="rvdh">'+focusH('rvdh','Delete this review?','trash','#9A2B21')
    +'<p class="sub">Deleting removes your review from the mentor\u2019s profile and rating straight away. This session keeps its one review slot, so you cannot write another review for it. You can delete at any time; this is not limited to the 7-day edit window.</p>'
    +note('ind','info','<b>Prototype.</b> Deletion is simulated here and nothing is sent. The backend contract is an owned soft delete (reviews.py delete).')
    +'<div class="stack" style="gap:8px">'+btn('danger b48','trash','Delete review','data-rvdel6="1"')+btn('b48','star','Keep my review','data-st="review-edit"','#2E3A8C')+'</div></section>');}
  if(st==='review-delete-failed'){
   if(!live06(r))return s35Shell(m,se,chips+statusNote('ind','info','There is no review to delete for this session.','Code: review_not_found.',back));
   return s35Shell(m,se,chips+alertNote('risk','warn','We could not delete your review.','Network error (simulated). Your review has not been deleted. Its moderation status is unchanged.',btn('b48','trash','Try again','data-st="review-delete-confirm"','#9A2B21')+back));}
  if(st==='review-deleted'){
   if(!(r&&r.deleted_ms))return s35Shell(m,se,chips+statusNote('ind','info','No deleted review for this session.','Nothing has been deleted.',back));
   return s35Shell(m,se,chips+statusNote('ok','checkc','Review deleted.','It no longer appears on the mentor\u2019s profile or rating. One review per session, so this session cannot get a new review. Prototype: simulated, nothing was sent.',back));}
  if(r&&r.deleted_ms){
   if(st==='review')return s35Shell(m,se,chips+alertNote('risk','warn','This session\u2019s review was deleted.','Code: review_duplicate. One review per session, including a deleted one, so another review cannot be written.',back));
   if(st==='review-edit'||st==='review-window-closed'||st==='review-invalid')return s35Shell(m,se,chips+statusNote('ind','info','There is no review to edit for this session.','Code: review_not_found. The review for this session was deleted.',back));
   if(st==='review-moderation')return s35Shell(m,se,chips+statusNote('ind','info','This session\u2019s review was deleted.','It is not on the mentor\u2019s profile or rating.',back));}
 }
 return s35_05(m,st).split('data-rvsubmit4="1"').join('data-rvcreate5="1"');}
function wire(vp){wire_05(vp);
 vp.querySelectorAll('[data-rvdel6]').forEach(function(b){b.addEventListener('click',function(){var se=byId(FX.sessions,A.q.session),r=se&&se.review05;
  if(!live06(r)){setState('review-delete-confirm');return;}
  r.deleted_ms=now04();r.was_published=r.moderation==='published';r.moderation='deleted';
  setState('review-deleted');ann('Review deleted.');});});
}
addStates('s35',[['review-delete-confirm','Delete review: confirmation (prototype, owned soft delete)'],['review-deleted','Review deleted: removed from profile and rating; one review per session remains'],['review-delete-failed','Delete review failed (simulated network error); nothing changed']]);
(function(){var m35=meta('s35');if(m35){m35.proto=(m35.proto||[]).concat(['v3.2.1.07: the mentor rating shown on S-31/S-32 (for example 4.8 from 31 ratings) is a static aggregate projection. The simulated review create/delete changes only the session review record; it is NOT proof of a live aggregate refresh. Backend contract: owned soft delete recomputes the public aggregate (reviews.py).','v3.2.1.06: every review state uses the same session-bound record. Review states opened without a session use the sample session se-2207 (written to the address); an explicit session is never replaced. Delete review is a prototype confirmation, success and simulated failure flow backed by the reviews.py soft-delete contract; nothing is sent. An unchanged Save shows local "No changes to save".']);
  m35.actions=(m35.actions||[]).concat([['Delete review','Delete review','review exists (any time, not limited to the edit window)','simulated DELETE (owned soft delete)','review-deleted, review-delete-failed','stays']]);}
 var m18=meta('s18');if(m18){m18.proto=['default: each change saves on its own (PATCH with expected_version); optional option-manual: draft plus Save/Discard (owner option B, not default)','language availability flag (frontend capability, not a server field)'];
  m18.actions=[['Toggle a notification','Email notifications, SMS notifications, Product and service updates (switch)','loaded','PATCH /student/settings (default save-on-change)','saving, saved, invalid, conflict, network','stays'],['Choose theme','System, Light, Dark','loaded','PATCH /student/settings (default save-on-change)','saving, saved','stays'],['Choose language','English (Hindi shown as Coming soon)','loaded','PATCH /student/settings (default save-on-change)','saving, saved','stays'],['Save changes / Discard','Save changes, Discard','option-manual only','PATCH once / none','saved or loaded','stays']];}})();
